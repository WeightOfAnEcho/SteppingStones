﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BT_Level03_Player : BT_Player_Base
{

    //This exists incase any edits to player base is required -------------------------------------------------------------------------------------------------
    protected override void Start()
    {
        base.Start(); // start base functionality heled in BT_Player_Base
    }
}
