﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DD_Room : MonoBehaviour
{

    public Vector4 doors = new Vector4(1, 1, 1, 1);
    public Vector4 Doors
    {
        get { return doors; }
    }
}
